/* 
 * May 23 2025
 * ShipType
 * A container class for each ship type.
 */

public class ShipType 
{
    public int length;
    public char shipVisual;
}
