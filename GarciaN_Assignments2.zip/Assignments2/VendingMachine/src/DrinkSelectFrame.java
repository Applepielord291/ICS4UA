public class DrinkSelectFrame {
    public void addSoda1()
    {
        Main.soda1.userBought += 1;
    }
    public void addSoda2()
    {
        Main.soda2.userBought += 1;
    }
    public void addSoda3()
    {
        Main.soda3.userBought += 1;
    }
    public void addSoda4()
    {
        Main.soda4.userBought += 1;
    }
    public void addSoda5()
    {
        Main.soda5.userBought += 1;
    }
}
