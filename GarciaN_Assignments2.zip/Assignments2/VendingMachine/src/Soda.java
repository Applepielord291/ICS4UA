/* Nigel garcia
 * April 11 2025
 * Soda
 * class used as a container for various types of sodas
 */

 //class container holds name, price, current and initial quantity information, and how many user bought
public class Soda {
    public String name;
    public double price;
    public int currentQuantity;
    public int initialQuantity;
    public int userBought;
}
